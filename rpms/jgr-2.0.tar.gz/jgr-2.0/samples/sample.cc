#include <stream.h>
#include <iostream.h>
#include <math.h>
#include <jkit/jgr.h>

extern "C" { double drand48(); }
JWindow win;
Graph	g;

main(){
  long i;
  double xmax, ymax, h;
  char *msg="Click the Mouse, Please!!";
  
  // $B%&%#%s%I%&$r$R$i$$$F!"$=$NCf$K%0%i%U$r$+$/(B
  win.open(10,10)		        // $B%&%#%s%I%&$r3+$/(B
    .graph(g.open( 500, 50, 200, 40 ))	// $B%&%#%s%I%&$NCf$K%0%i%U$r3+$/(B
    .map()				// $B%&%#%s%I%&IA2h(B
    .mouse_wait(); 		// $B%^%&%9%/%j%C%/$rBT$D(B
  
  xmax = 10.0;	ymax = 100.0;
  g.set_ratio( xmax, ymax, 500.0, 200.0 );
  //$B>e$GDj5A$7$?%0%i%U$N%9%1!<%j%s%0%Q%i%a!<%?$r@_Dj(B
  // x$B<4$G$O(B, $BCM(B10.0$B$r%9%/%j!<%s>e$N(B500$B%I%C%H$K$9$k(B
  // y$B<4$G$O(B, $BCM(B100.0$B$r%9%/%j!<%s>e$N(B200$B%I%C%H$K$9$k(B
  
  // $B:BI8<4$r=q$/(B --------------------------------------------------------
  g.axis()			// x,y$B:BI8<4$r=q$/(B
    .text( 5, -15, msg )	// $B%a%C%;!<%8$rIA$/(B
    .flush()			// $B%0%i%U%#%C%/%P%C%U%!$r%U%i%C%7%e(B
    .mouse_wait(); 		// $B%^%&%9%/%j%C%/$rBT$D(B
  
  // $B;M3Q$G0O$^$l$?:BI8<4$r=q$/(B-------------------------------------------
  g.axis_box()			// $B;M3Q$G0O$^$l$?:BI8<4$r=q$/(B
    .text( 5, -15, msg )	// $B%a%C%;!<%8$rIA$/(B
    .flush()			// $B%0%i%U%#%C%/%P%C%U%!$r%U%i%C%7%e(B
    .mouse_wait(); 		// $B%^%&%9%/%j%C%/$rBT$D(B
  
  // $BD>@~$rIA$/(B ----------------------------------------------------------
  for( double i=1.0; i<=xmax; i+=0.1 ){
    g.color("green")
      .line( (double)i, 0.0, 0.0, (xmax-(double)i)*ymax/xmax )
      .text( 5, -15, msg )	// $B%a%C%;!<%8$rIA$/(B
      .flush();		        // $B%0%i%U%#%C%/%P%C%U%!$r%U%i%C%7%e(B
    mouse_break();		// $B%^%&%9%/%j%C%/$,$"$l$P(B break($B%^%/%mDj5A(B)
  }
  
  g.color("black")
    .text( 5, -15, msg )
    .mouse_wait();
  
  // $B1_$rIA$/(B -------------------------------------------------------------
  double r=1.0;			// $BH>7BDj5A(B
  h=0.1;
  for( i=1; h*(double)i+2.0*r <=xmax; ++i ){
    g.clear()                   // $B%0%i%U$r>C$9(B
      .axis_box()		// $B:BI8<4$rIA$/(B($B>e5-;2>H(B)
      .color("red")
      .circle( h*(double)i+r, 25.0, r ) //$B1_$rIA$/(B
      .flush()
      .color("black");
    for(int j=1; j<2000000; ++j ); // wait a moment...
    mouse_break();		// $B%^%&%9%/%j%C%/$,$"$l$P(B break($B%^%/%mDj5A(B)
  }
  
  g.color("red")
    .fill_circle( h*(double)(i-1)+r, 25.0, r ) //$BEI$j$D$V$7$?1_$rIA$/(B
    .color("black")
    .text( 5, -15, msg)
    .flush()
    .mouse_wait();
  
  // $B;M3Q7A$rIA$/(B --------------------------------------------------------
  double width = 2.0;
  double height = 20.0;
  h=0.05;
  for( i=1; h*(double)i+width <=xmax; ++i ){
    g.clear()                   // $B%0%i%U$r>C$9(B
      .axis_box()
      .rectangle( h*(double)i, height, width, height )//$B;M3Q7A$rIA$/(B
      .flush();
    mouse_break();
    for(int j=1; j<1000000; ++j ); // wait a moment...
  }
  
  g.fill_rectangle( h*(double)(i-1), height, width, height )//$BEI$j$D$V$7$?;M3Q7A$rIA$/(B
    .mouse_wait();
  
  // $BE@$rIA$/(B --------------------------------------------------------
  g.clear()
    .set_scale_full()
    .axis_box();
  h=0.0002;
  for( i=1; i <=(int)(1.0/h); ++i ){
    g.color("blue")
      .pset( (1-i*h)*xmax*drand48(), (1-i*h)*ymax*drand48() )//$BE@$rIA$/(B
      .flush();
    mouse_break();
  }
  
  g.color("black")
    .text( 5, -15, msg)
    .mouse_wait();
  
  // end  --------------------------------------------------------
  Xwin.close();         	// $B$*$o$j(B
}
